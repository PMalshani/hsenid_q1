package com.coffe.web.service.impl;

import com.coffe.web.dto.ProductDTO;
import com.coffe.web.entity.Product;
import com.coffe.web.repository.ProductRepository;
import com.coffe.web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository repo;

    @Override
    public List<ProductDTO> listAll() throws Exception {
        return repo.findAll().stream().map(x->
                new ProductDTO(x.getId(),x.getName(),x.getDescription(),x.getPrice())).collect(Collectors.toList());
    }
}

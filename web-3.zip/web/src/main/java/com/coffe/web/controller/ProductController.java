package com.coffe.web.controller;

import com.coffe.web.dto.ProductDTO;
import com.coffe.web.service.ProductService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private ProductService service;

    @GetMapping("/products")
    public List<ProductDTO> list() {
        try {
            return service.listAll();
        }catch (Exception e){
            return null;
        }
    }

}

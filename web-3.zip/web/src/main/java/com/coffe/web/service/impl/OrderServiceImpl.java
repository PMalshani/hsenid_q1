package com.coffe.web.service.impl;

import com.coffe.web.dto.OrderDTO;
import com.coffe.web.dto.ProductsItem;
import com.coffe.web.entity.Order;
import com.coffe.web.entity.Product;
import com.coffe.web.repository.OrderProductRepository;
import com.coffe.web.repository.OrderRepository;
import com.coffe.web.repository.ProductRepository;
import com.coffe.web.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderProductRepository orderProductRepository;

    @Override
    @Transactional
    public Order createOrder(OrderDTO orderDTO) throws Exception {
        System.out.println(orderDTO.getUserId());
        Order order = orderRepository.save(new Order(new Date(), orderDTO.getUserId()));
        List<ProductsItem> products = orderDTO.getProducts();
        products.forEach(item->{
            Optional<Product> optionalProduct = productRepository.findById(item.getProductId());
            if(optionalProduct.isPresent()){
                Product product = optionalProduct.get();
                order.getProducts().add(product);
                orderRepository.save(order);
            }
        });
        return order;
    }
}

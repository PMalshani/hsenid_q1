package com.coffe.web.service;

import com.coffe.web.dto.OrderDTO;
import com.coffe.web.dto.ProductDTO;
import com.coffe.web.entity.Order;

import java.util.List;

public interface OrderService {
    public Order createOrder(OrderDTO orderDTO) throws Exception;
}

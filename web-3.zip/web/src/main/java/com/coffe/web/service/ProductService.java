package com.coffe.web.service;

import com.coffe.web.dto.ProductDTO;
import com.coffe.web.entity.Product;

import java.util.List;

public interface ProductService {
    public List<ProductDTO> listAll() throws Exception;
}

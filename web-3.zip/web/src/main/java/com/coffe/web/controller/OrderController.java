package com.coffe.web.controller;

import com.coffe.web.dto.OrderDTO;
import com.coffe.web.dto.PersistedObjId;
import com.coffe.web.entity.Order;
import com.coffe.web.service.OrderService;
import com.coffe.web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @ResponseStatus(value = HttpStatus.CREATED)
    @RequestMapping(path = "", method = RequestMethod.POST)
    public PersistedObjId createInvoice(@RequestBody @Valid OrderDTO orderDTO) throws Exception {
        Order order = orderService.createOrder(orderDTO);
        return new PersistedObjId(order.getId());
    }

}
